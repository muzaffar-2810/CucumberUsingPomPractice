package allFeatures;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegisterStepDefinitions {
	public WebDriver driver;
	@Given("^user should be in regitration page$")
	public void user_should_be_in_regitration_page() {
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.get("http://127.0.0.1:5000/register");
	}

	@When("^user enters the username$")
	public void user_enters_the_username() {
	    WebElement usernameTF = driver.findElement(By.xpath("//input[@name='name']"));
	    usernameTF.clear();
	    usernameTF.sendKeys("MUZZ143");
	}

	@When("^user enters password$")
	public void user_enters_password() {
		WebElement passwordTF = driver.findElement(By.xpath("//input[@name='password']"));
		passwordTF.clear();
		passwordTF.sendKeys("MUZZ143");
	}

	@When("user clicks on register button")
	public void user_clicks_on_register_button() {
		WebElement RegisterButton = driver.findElement(By.xpath("//button[text()='Register']"));
		RegisterButton.click();
	}
	@Then("^user should be navigated to dashboard page$")
	public void user_should_be_navigated_to_dashboard_page() {
	    String expectedTitle = "FLASK-CRUD_APP_register_page.";
	    String actualTitle = driver.getTitle();
	    if(expectedTitle.equals(actualTitle)) {
	    	System.out.println("OK");
	    }else {
	    	System.out.println();
	    }
	    
	}
}
